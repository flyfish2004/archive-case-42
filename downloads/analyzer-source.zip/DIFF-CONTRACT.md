# `compareFiles(baseFile, otherFile, options?)`

No dependencies; native ES module for modern browsers and Node. Each file is
`{bytes: Uint8Array, text: string | null, format: {encoding: string}}`.
Pass strictly decoded text with the encoding's initial BOM removed. Binary or
undecodable files should use `text: null`. The module does not infer encoding.

## Main fields

- `equal`: exact equality of the input bytes, unaffected by diff limits.
- `byteChanges`: at most 100 byte hunks by default. `beforeStart`, `beforeEnd`,
  `afterStart`, `afterEnd` are zero-based byte ranges with exclusive ends.
- `textChanges`: separate decoded-Unicode hunks, at most 100 by default. Their
  offsets count Unicode code points, not bytes or UTF-16 code units. `null`
  means text could not be compared or its size budget prevented analysis.
- A hunk's `type` is `replace`, `insert`, or `delete`. `exact: true` means it
  comes from a shortest insertion/deletion script. Consecutive insertion and
  deletion steps are grouped as one replacement. Alignment ties use a stable
  choice; the minimal script need not be unique.
- `beforeHex` and `afterHex` exist on byte hunks only; uppercase, space-separated,
  capped at 64 bytes per side by default. `beforePreviewBytes` /
  `afterPreviewBytes` report the preview lengths.
- `beforeText` / `afterText` contain escaped literal text without outer quotes.
  LF, CR, TAB, spaces, controls, and default-ignorable Unicode characters are
  explicit (`\\n`, `\\r`, `\\t`, `\\u0020`, etc.). Byte fragments which bisect a
  scalar/code unit or have unsupported encodings use `null` for text.
- `beforePreviewTruncated` / `afterPreviewTruncated` say whether that side's
  preview is shorter than the entire hunk. Text previews default to 96 code points.
- `beforeLocation` / `afterLocation` are `null` on byte hunks. On text hunks
  they are `{line, column}`, both starting at 1; columns count Unicode code
  points. `beforeEndLocation` / `afterEndLocation` also exist on text hunks.
  CRLF counts as one newline after LF; lone CR and lone LF each end a line.
- `totalByteHunks` / `totalTextHunks` count all found hunks, even when only the
  first 100 are returned. `byteHunksTruncated` / `textHunksTruncated` disclose
  that display limit. On bounded alignment these counts are envelope counts,
  not an assertion of the actual number of separate minimal edit regions.
- `textComparable` says both supplied texts are strings. `textAnalysisPerformed`
  additionally says a Unicode alignment was performed (or exact text equality
  was established). `textEqual` is an exact string comparison, or `null` for
  nontext inputs. Equal decoded text can have different bytes because of BOM,
  encoding, or other byte representations supplied by the caller.

## Bounds, counts, and honest presentation

`byteAlignment` and `textAlignment` are `exact` or `bounded`; unperformed text
analysis has `textAlignment: null`. Overall `alignment` is `exact` only when
all applicable analyses are exact. Byte equality itself is always exact.

Common equal prefix/suffix is removed first. A bounded Myers algorithm then
finds a shortest script, subject to these options:

| Option | Default | Meaning |
| --- | ---: | --- |
| `maxWork` | 2,000,000 | Myers frontier steps plus equal-diagonal steps, per analysis |
| `maxTraceCells` | 1,000,000 | Stored Int32 frontier cells; hard maximum 8,000,000 |
| `maxEditDistance` | 2,048 | Insertion/deletion distance to search; hard maximum 8,192 |
| `maxTextCodeUnits` | 2,000,000 | Maximum decoded input length per file before Unicode tokenization |
| `maxByteHunks` | 100 | Returned byte hunks; all found hunks still counted |
| `maxTextHunks` | 100 | Returned text hunks; all found hunks still counted |
| `previewBytes` | 64 | Byte preview length per hunk side |
| `previewCodePoints` | 96 | Unicode preview length per hunk side |

Each option must be a nonnegative safe integer. Common prefix/suffix comparison
is linear in input size and not limited by `maxWork`. Pure contiguous insertion
or deletion after prefix/suffix removal is exact without a Myers search.

When a Myers budget is reached, the module returns one `exact: false` hunk
covering the changed middle. It is an exact envelope, **not a minimal edit**.
`analysisLimits` lists `{analysis, limit, value, effect}` for each limitation.
Display that limitation clearly and label the hunk as a range, not as the
precise set of edits. The strings in `effect` are machine-readable English
explanations; the host UI can translate them.

`summary.removedBytes` / `addedBytes` count bytes deleted/inserted in the exact
script. A replaced 2-byte value counts as 2 removed and 2 added. They are
`null` for bounded byte alignment. `rangeRemovedBytes` / `rangeAddedBytes`
always sum the returned alignment's **full** ranges, including undisplayed
hunks; for bounded alignment this includes unchanged content inside an envelope.
`removedCodePoints` / `addedCodePoints` follow the same exact-or-null rule.
`byteEditDistance` / `textEditDistance` are the exact insertion+deletion cost,
or `null` when not established. `beforeBytes`, `afterBytes`, and
`byteLengthDelta` are always exact file sizes.

## Verification

Run `node independent-audit/diff-work/diff.test.mjs`. Assertions cover 16 → 42
at zero-based byte 41, insertions, deletions, empty input, CRLF/LF, Unicode code
point locations, UTF-16 and BOM, disjoint edits, truncation, resource limits,
binary inputs, reconstruction of both inputs from hunks, and 3,969 exhaustive
small input pairs compared to an independent dynamic-programming oracle.
